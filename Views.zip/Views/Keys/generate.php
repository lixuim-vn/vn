<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center">
    <div class="col-lg-6">
        <?= $this->include('Layout/msgStatus') ?>

        <!-- Flash data success message -->
        <?php if (session()->getFlashdata('user_key')) : ?>
            <div class="alert alert-success shadow-lg rounded-3 p-3" role="alert">
                <h5><strong><i class="bi bi-gamepad text-primary"></i> Game:</strong> <?= session()->getFlashdata('game') ?> / <?= session()->getFlashdata('duration') ?> Hours</h5>
                <p><strong><i class="bi bi-key text-warning"></i> License:</strong> <span class="key-sensi"><?= session()->getFlashdata('user_key') ?></span></p>
                <p>Available for <strong><i class="bi bi-device-laptop text-secondary"></i> <?= session()->getFlashdata('max_devices') ?></strong> Devices</p>
                <small>
                    <i class="bi bi-info-circle"></i> <i>Duration will start when the license logs in.</i><br>
                    <i class="bi bi-wallet2"></i> <strong>Saldo Reduce:</strong>
                    <span class="text-danger">- ₹ <?= session()->getFlashdata('fees') ?></span>
                    (Total left: ₹ <?= $user->saldo ?>)
                </small>
            </div>
        <?php endif; ?>

        <!-- Card for Creating License -->
        <div class="card shadow-xl border-0 rounded-lg">
            <div class="card-header bg-gradient-primary text-white rounded-top">
                <div class="row align-items-center">
                    <div class="col pt-1">
                        <!-- New title icon and color change -->
                        <h5><i class="bi bi-lock-fill text-dark"></i> <span class="text-dark">Create License</span></h5>
                    </div>
                    <div class="col text-end">
                        <a class="btn btn-outline-light btn-sm" href="<?= site_url('keys') ?>"><i class="bi bi-person-badge text-dark"></i></a>
                    </div>
                </div>
            </div>
            <div class="card-body bg-light p-4">
                <?= form_open() ?>
                <div class="row">
                    <div class="col-lg-6 mb-3">
                        <label for="game" class="form-label"><i class="bi bi-controller text-primary"></i> Select Game</label>
                        <?= form_dropdown(['class' => 'form-select shadow-sm border-0', 'name' => 'game', 'id' => 'game'], $game, old('game') ?: '') ?>
                        <?php if ($validation->hasError('game')) : ?>
                            <small class="text-danger"><?= $validation->getError('game') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label for="max_devices" class="form-label"><i class="bi bi-laptop text-secondary"></i> Max Devices</label>
                        <input type="number" name="max_devices" id="max_devices" class="form-control shadow-sm border-0" placeholder="1" value="<?= old('max_devices') ?: 1 ?>">
                        <?php if ($validation->hasError('max_devices')) : ?>
                            <small class="text-danger"><?= $validation->getError('max_devices') ?></small>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="duration" class="form-label"><i class="bi bi-clock text-warning"></i> Duration</label>
                    <?= form_dropdown(['class' => 'form-select shadow-sm border-0', 'name' => 'duration', 'id' => 'duration'], $duration, old('duration') ?: '') ?>
                    <?php if ($validation->hasError('duration')) : ?>
                        <small class="text-danger"><?= $validation->getError('duration') ?></small>
                    <?php endif; ?>
                </div>
                <div class="mb-3">
                    <label for="estimation" class="form-label"><i class="bi bi-currency-exchange text-success"></i> Estimation</label>
                    <input type="text" id="estimation" class="form-control shadow-sm border-0 bg-light" placeholder="Your order will total" readonly>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-gradient-warning w-100"><i class="bi bi-arrow-right-circle-fill"></i> Generate License</button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    $(document).ready(function() {
        var price = JSON.parse('<?= $price ?>');
        getPrice(price);
        
        // When selected
        $("#max_devices, #duration, #game").change(function() {
            getPrice(price);
        });
        
        // Calculate price
        function getPrice(price) {
            var device = $("#max_devices").val();
            var durate = $("#duration").val();
            var gprice = price[durate];
            if (!isNaN(gprice)) {
                var result = (device * gprice);
                $("#estimation").val('₹ ' + result);
            } else {
                $("#estimation").val('Estimation error');
            }
        }
    });
</script>
<?= $this->endSection() ?>