<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="row justify-content-center align-items-center min-vh-100" style="background-color: #fff;">
    <div class="col-lg-4">
        <?= $this->include('Layout/msgStatus') ?>
        <div class="card shadow-lg border-0 mb-5">
            <div class="card-header text-center bg-primary text-white h4 p-3">
                <i class="bi bi-person-plus-fill"></i> Register
            </div>
            <div class="card-body p-4">
                <?= form_open() ?>
                
                <!-- Username Field -->
                <div class="form-group mb-4">
                    <label for="username" class="form-label text-secondary">Username</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person"></i></span>
                        <input type="text" class="form-control" name="username" id="username" placeholder="Enter your username" required minlength="4" value="<?= old('username') ?>">
                    </div>
                    <?php if ($validation->hasError('username')) : ?>
                        <small id="help-username" class="form-text text-danger"><?= $validation->getError('username') ?></small>
                    <?php endif; ?>
                </div>
                
                <!-- Password Field -->
                <div class="form-group mb-4">
                    <label for="password" class="form-label text-secondary">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock"></i></span>
                        <input type="password" class="form-control" name="password" id="password" placeholder="Enter your password" required minlength="6">
                    </div>
                    <?php if ($validation->hasError('password')) : ?>
                        <small id="help-password" class="form-text text-danger"><?= $validation->getError('password') ?></small>
                    <?php endif; ?>
                </div>
                
                <!-- Confirm Password Field -->
                <div class="form-group mb-4">
                    <label for="password2" class="form-label text-secondary">Confirm Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock"></i></span>
                        <input type="password" class="form-control" name="password2" id="password2" placeholder="Confirm your password" required minlength="6">
                    </div>
                    <?php if ($validation->hasError('password2')) : ?>
                        <small id="help-password2" class="form-text text-danger"><?= $validation->getError('password2') ?></small>
                    <?php endif; ?>
                </div>
                
                <!-- Referral Code Field -->
                <div class="form-group mb-4">
                    <label for="referral" class="form-label text-secondary">Referral Code</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person-check"></i></span>
                        <input type="text" class="form-control" name="referral" id="referral" placeholder="Enter referral code" value="<?= old('referral') ?>" maxlength="25">
                    </div>
                    <?php if ($validation->hasError('referral')) : ?>
                        <small id="help-referral" class="form-text text-danger"><?= $validation->getError('referral') ?></small>
                    <?php endif; ?>
                </div>

                <!-- Submit Button -->
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-person-plus"></i> Register
                    </button>
                </div>
                
                <?= form_close() ?>
            </div>
        </div>
        <div class="text-center text-dark mt-4">
            <p>
                <small>Already have an account? 
                    <a href="<?= site_url('login') ?>" class="text-primary">Login here</a>
                </small>
            </p>
        </div>
    </div>
</div>

<?= $this->endSection() ?>