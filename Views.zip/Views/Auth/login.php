<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="row justify-content-center align-items-center min-vh-100" style="background-color: #fff;">
    <div class="col-lg-4">
        <?= $this->include('Layout/msgStatus') ?>
        <div class="card shadow-lg border-0 mb-5">
            <div class="card-header text-center bg-primary text-white h4 p-3">
                <i class="bi bi-person-circle"></i> Login
            </div>
            <div class="card-body p-4">
                <?= form_open() ?>
                <div class="form-group mb-4">
                    <label for="username" class="form-label text-secondary">Username</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person"></i></span>
                        <input type="text" class="form-control" name="username" id="username" placeholder="Enter your username" required minlength="4">
                    </div>
                    <?php if ($validation->hasError('username')) : ?>
                        <small id="help-username" class="form-text text-danger"><?= $validation->getError('username') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-4">
                    <label for="password" class="form-label text-secondary">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock"></i></span>
                        <input type="password" class="form-control" name="password" id="password" placeholder="Enter your password" required minlength="6">
                    </div>
                    <?php if ($validation->hasError('password')) : ?>
                        <small id="help-password" class="form-text text-danger"><?= $validation->getError('password') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-check mb-4">
                    <input type="checkbox" class="form-check-input" name="stay_log" id="stay_log" value="yes">
                    <label class="form-check-label text-secondary" for="stay_log">Stay logged in?</label>
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-box-arrow-in-right"></i> Log in
                    </button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
        <div class="text-center text-dark mt-4">
            <p>
                <small>Don't have an account? 
                    <a href="<?= site_url('register') ?>" class="text-primary">Register here</a>
                </small>
            </p>
        </div>
    </div>
</div>

<?= $this->endSection() ?>