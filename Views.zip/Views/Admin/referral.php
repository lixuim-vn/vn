<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<div class="row">
    <div class="col-lg-12 mb-4">
        <?= $this->include('Layout/msgStatus') ?>
    </div>

    <!-- Card for Generate Code -->
    <div class="col-lg-4 mb-3">
        <div class="card shadow-lg border-0 rounded-lg">
            <div class="card-header bg-gradient-primary text-white p-3">
                <h5><i class="bi bi-key-fill"></i> Generate <?= $title ?></h5>
            </div>
            <div class="card-body">
                <?= form_open() ?>
                <div class="form-group mb-3">
                    <label for="set_saldo"><i class="bi bi-currency-dollar"></i> You can set with multiple saldo</label>
                    <div class="input-group mt-2">
                        <span class="input-group-text"><i class="bi bi-currency-dollar"></i></span>
                        <input type="number" class="form-control shadow-sm border-0" name="set_saldo" id="set_saldo" minlength="1" maxlength="11" value="5">
                    </div>
                    <?php if ($validation->hasError('set_saldo')) : ?>
                        <small id="help-saldo" class="text-danger"><?= $validation->getError('set_saldo') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-outline-primary w-100">
                        <i class="bi bi-arrow-right-circle-fill"></i> Create Code
                    </button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>

    <!-- Card for Code History -->
    <div class="col-lg-8">
        <?php if ($code) : ?>
            <div class="card shadow-lg border-0 rounded-lg">
                <div class="card-header bg-gradient-info text-white p-3">
                    <h5><i class="bi bi-history"></i> History Generate - Total <?= $total_code ?></h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover text-center" style="width:100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Referral Hashed</th>
                                    <th>Saldo</th>
                                    <th>Used By</th>
                                    <th>Created By</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($code as $c) : ?>
                                    <tr>
                                        <td><i class="bi bi-check-circle"></i> <?= $c->id_reff ?></td>
                                        <td><?= substr($c->code, 1, 15) ?> <i class="bi bi-shield-lock"></i></td>
                                        <td><i class="bi bi-currency-dollar"></i> $<?= $c->set_saldo ?></td>
                                        <td><?= $c->used_by ?: '<span class="text-muted">—</span>' ?></td>
                                        <td><i class="bi bi-person-circle"></i> <?= $c->created_by ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?= $this->endSection() ?>