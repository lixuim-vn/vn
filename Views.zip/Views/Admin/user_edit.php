<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center pt-4">
    <div class="col-lg-8">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
    <div class="col-lg-8 mb-5">
        <div class="card shadow-lg border-0 rounded-lg">
            <div class="card-header bg-info text-white h5 p-3">
                <i class="bi bi-person-circle"></i> Edit Account &middot; <?= getName($target) ?>
            </div>
            <div class="card-body">
                <?= form_open() ?>
                <input type="hidden" name="user_id" value="<?= $target->id_users ?>">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="username" class="form-label"><i class="bi bi-person-fill"></i> Username</label>
                        <input type="text" name="username" id="username" class="form-control" value="<?= old('username') ?: $target->username ?>" placeholder="Enter Username" aria-describedby="help-username">
                        <?php if ($validation->hasError('username')) : ?>
                            <small id="help-username" class="form-text text-danger"><?= $validation->getError('username') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="fullname" class="form-label"><i class="bi bi-person-lines-fill"></i> Fullname</label>
                        <input type="text" name="fullname" id="fullname" class="form-control" value="<?= old('fullname') ?: $target->fullname ?>" placeholder="Enter Full Name" aria-describedby="help-fullname">
                        <?php if ($validation->hasError('fullname')) : ?>
                            <small id="help-fullname" class="form-text text-danger"><?= $validation->getError('fullname') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="level" class="form-label"><i class="bi bi-briefcase-fill"></i> Roles</label>
                        <?php $sel_level = ['' => '&mdash; Select Roles &mdash;', '1' => 'Admin', '2' => 'Reseller']; ?>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'level', 'id' => 'level'], $sel_level, $target->level) ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="status" class="form-label"><i class="bi bi-shield-lock"></i> Status</label>
                        <?php $sel_status = ['' => '&mdash; Select Status &mdash;', '0' => 'Banned/Block', '1' => 'Active']; ?>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'status', 'id' => 'status'], $sel_status, $target->status) ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="saldo" class="form-label"><i class="bi bi-cash-stack"></i> Saldo</label>
                        <input type="number" name="saldo" id="saldo" class="form-control" value="<?= old('saldo') ?: $target->saldo ?>" placeholder="Enter Saldo" aria-describedby="help-saldo">
                        <?php if ($validation->hasError('saldo')) : ?>
                            <small id="help-saldo" class="form-text text-danger"><?= $validation->getError('saldo') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="uplink" class="form-label"><i class="bi bi-arrow-up-circle"></i> Uplink</label>
                        <input type="text" name="uplink" id="uplink" class="form-control" value="<?= old('uplink') ?: $target->uplink ?>" placeholder="Enter Uplink" aria-describedby="help-uplink">
                        <?php if ($validation->hasError('uplink')) : ?>
                            <small id="help-uplink" class="form-text text-danger"><?= $validation->getError('uplink') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-12 mb-3">
                        <button type="submit" class="btn btn-outline-info w-100">
                            <i class="bi bi-save"></i> Update Account Information
                        </button>
                    </div>
                </div>
                <?= form_close() ?>
            </div>
        </div>

        <p class="text-muted text-center">
            <a href="<?= site_url('admin/manage-users') ?>" class="py-1 px-2 text-danger"><small><i class="bi bi-arrow-left-circle"></i> Back to Manage Users</small></a>
        </p>
    </div>
</div>
<?= $this->endSection() ?>