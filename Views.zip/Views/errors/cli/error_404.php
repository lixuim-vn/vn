<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 Page Not Found</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Arial", sans-serif;
            background: linear-gradient(135deg, #ff6a6a, #ffa06d);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            overflow: hidden;
        }
        .container {
            text-align: center;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            background: rgba(255, 255, 255, 0.1);
        }
        h1 {
            font-size: 6rem;
            margin: 0;
            font-weight: bold;
            color: #fff;
        }
        p {
            font-size: 1.5rem;
            margin: 20px 0;
            line-height: 1.5;
        }
        a {
            text-decoration: none;
            color: #fff;
            background: #ff4444;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 1.2rem;
            transition: background 0.3s ease;
        }
        a:hover {
            background: #ff2222;
        }
        .icon {
            font-size: 8rem;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon">😢</div>
        <h1>404</h1>
        <p>
            <?php if (! empty($message) && $message !== '(null)') : ?>
                <?= nl2br(esc($message)) ?>
            <?php else : ?>
                Oops! We can't find the page you're looking for.
            <?php endif ?>
        </p>
        <a href="/">Go Back to Home</a>
    </div>
</body>
</html>