<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="row">
    <div class="col-lg-12 mb-4">
        <?= $this->include('Layout/msgStatus') ?>
    </div>

    <!-- Card for Change Password -->
    <div class="col-lg-6 mb-3">
        <div class="card shadow-lg border-0 rounded-lg">
            <div class="card-header bg-gradient-primary text-white p-3">
                <h5><i class="bi bi-lock-fill"></i> Change Password</h5>
            </div>
            <div class="card-body">
                <?= form_open() ?>

                <input type="hidden" name="password_form" value="1">
                
                <div class="form-group mb-3">
                    <label for="current"><i class="bi bi-key-fill"></i> Current Password</label>
                    <input type="password" name="current" id="current" class="form-control mt-2" placeholder="Current Password">
                    <?php if ($validation->hasError('current')) : ?>
                        <small id="help-current" class="text-danger"><?= $validation->getError('current') ?></small>
                    <?php endif; ?>
                </div>
                
                <div class="form-group mb-3">
                    <label for="password"><i class="bi bi-lock"></i> New Password</label>
                    <input type="password" name="password" id="password" class="form-control mt-2" placeholder="New Password" aria-describedby="help-password">
                    <?php if ($validation->hasError('password')) : ?>
                        <small id="help-password" class="text-danger"><?= $validation->getError('password') ?></small>
                    <?php endif; ?>
                </div>
                
                <div class="form-group mb-3">
                    <label for="password2"><i class="bi bi-lock-fill"></i> Confirm Password</label>
                    <input type="password" name="password2" id="password2" class="form-control mt-2" placeholder="Confirm Password" aria-describedby="help-password2">
                    <?php if ($validation->hasError('password2')) : ?>
                        <small id="help-password2" class="text-danger"><?= $validation->getError('password2') ?></small>
                    <?php endif; ?>
                </div>
                
                <div class="form-group my-2">
                    <button type="submit" class="btn btn-outline-primary w-100"><i class="bi bi-arrow-right-circle-fill"></i> Change Password</button>
                </div>

                <?= form_close() ?>
            </div>
        </div>
    </div>

    <!-- Card for Account Information -->
    <div class="col-lg-6 mb-3">
        <div class="card shadow-lg border-0 rounded-lg">
            <div class="card-header bg-gradient-success text-white p-3">
                <h5><i class="bi bi-person-circle"></i> Account Information</h5>
            </div>
            <div class="card-body">
                <?= form_open() ?>

                <input type="hidden" name="fullname_form" value="1">

                <div class="form-group mb-3">
                    <label for="fullname"><i class="bi bi-person-fill"></i> Full Name</label>
                    <input type="text" name="fullname" id="fullname" class="form-control mt-2" placeholder="Enter Full Name" aria-describedby="help-fullname" value="<?= old('fullname') ?: ($user->fullname ?: '') ?>">
                    <?php if ($validation->hasError('fullname')) : ?>
                        <small id="help-fullname" class="text-danger"><?= $validation->getError('fullname') ?></small>
                    <?php endif; ?>
                </div>

                <div class="form-group my-2">
                    <button type="submit" class="btn btn-outline-success w-100"><i class="bi bi-pencil-square"></i> Update Account</button>
                </div>

                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>