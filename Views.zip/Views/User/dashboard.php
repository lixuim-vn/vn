<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="row">
    <!-- User Information (Tách thành bảng riêng biệt, không có chữ "Information") -->

    <!-- Roles -->
    <div class="col-lg-4 mb-4">
        <div class="card shadow-lg border-0" style="background-color: #fff;">
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <td class="text-center" colspan="2">
                            <i class="bi bi-person-badge text-primary" style="font-size: 3rem;"></i>
                        </td>
                    </tr>
                    <tr>
                        <th style="font-size: 1.5rem;">Roles</th>
                        <td class="text-center" style="font-size: 1.3rem;"><?= getLevel($user->level) ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <!-- Saldo -->
    <div class="col-lg-4 mb-4">
        <div class="card shadow-lg border-0" style="background-color: #fff;">
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <td class="text-center" colspan="2">
                            <i class="bi bi-wallet2 text-success" style="font-size: 3rem;"></i>
                        </td>
                    </tr>
                    <tr>
                        <th style="font-size: 1.5rem;">Saldo</th>
                        <td class="text-center" style="font-size: 1.3rem;">₹ <?= $user->saldo ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <!-- Login Time -->
    <div class="col-lg-4 mb-4">
        <div class="card shadow-lg border-0" style="background-color: #fff;">
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <td class="text-center" colspan="2">
                            <i class="bi bi-clock text-info" style="font-size: 3rem;"></i>
                        </td>
                    </tr>
                    <tr>
                        <th style="font-size: 1.5rem;">Login Time</th>
                        <td class="text-center" style="font-size: 1.3rem;"><?= $time::parse(session()->time_since)->humanize() ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <!-- Clients -->
    <div class="col-lg-4 mb-4">
        <div class="card shadow-lg border-0" style="background-color: #fff;">
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <td class="text-center" colspan="2">
                            <i class="bi bi-laptop text-warning" style="font-size: 3rem;"></i>
                        </td>
                    </tr>
                    <tr>
                        <th style="font-size: 1.5rem;">Clients</th>
                        <td class="text-center" style="font-size: 1.3rem;">
                            <?= isset($user->clients) ? $user->clients : 'No Clients' ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <!-- Registration History -->
    <div class="col-lg-12 mb-4">
        <div class="card shadow-lg mb-4" style="background-color: #fff;">
            <div class="card-header text-white bg-gradient-dark">
                <h5 class="mb-0">Registration History</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover text-center table-striped">
                        <thead class="table-dark">
                            <tr>
                                <th>#History ID <i class="bi bi-file-earmark-person text-primary"></i></th>
                                <th>Details <i class="bi bi-info-circle text-secondary"></i></th>
                                <th>Status <i class="bi bi-check-circle text-success"></i></th>
                                <th>Duration <i class="bi bi-clock-history text-warning"></i></th>
                                <th>Devices <i class="bi bi-phone text-muted"></i></th>
                                <th>Created At <i class="bi bi-calendar text-danger"></i></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($history as $h) : ?>
                                <?php $in = explode("|", $h->info) ?>
                                <tr class="hover-effect" style="transition: transform 0.3s ease, box-shadow 0.3s ease;">
                                    <td><span class="badge bg-success">#3812<?= $h->id_history ?></span></td>
                                    <td><span class="badge bg-info"><i class="bi bi-file-earmark-text"></i> <?= $in[0] ?></span></td>
                                    <td><span class="badge bg-success"><i class="bi bi-check-circle"></i> <?= $in[1] ?>**</span></td>
                                    <td><span class="badge bg-warning"><i class="bi bi-clock"></i> <?= $in[2] ?> Hours</span></td>
                                    <td><span class="badge bg-primary"><i class="bi bi-device-ssd"></i> <?= $in[3] ?> Devices</span></td>
                                    <td><i class="badge bg-danger"><i class="bi bi-calendar-day"></i> <?= $time::parse($h->created_at)->humanize() ?></i></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<!-- Thêm một số style cải tiến -->
<style>
    .table-striped tbody tr:hover {
        background-color: rgba(0, 123, 255, 0.1);
        transform: scale(1.02);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .table th, .table td {
        padding: 12px;
        vertical-align: middle;
        font-size: 1.1rem;
    }

    .badge {
        font-size: 1rem;
        padding: 0.4rem;
    }

    .card-header {
        border-bottom: 2px solid #e0e0e0;
    }

    .card-body {
        padding: 1.5rem;
    }
</style>