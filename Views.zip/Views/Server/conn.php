<?php

$servername = "localhost";
$username = "snueeiol_Hakura";
$password = "tfmbyH2fPy4g22dhnuaY";
$dbname = "snueeiol_Hakura";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>